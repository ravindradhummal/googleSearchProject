package TestScripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import io.github.bonigarcia.wdm.WebDriverManager;

public class SuperTestNg {
	
	WebDriver driver;
	
	@BeforeClass
	public void WebDriverManagerTest()
    {
//      WebDriverManager.chromedriver().setup();		
//      driver = new ChromeDriver();
		WebDriverManager.phantomjs().setup();
		driver= new PhantomJSDriver();
        driver.manage().window().maximize();
    }
 
	@AfterClass
	public void closeBrowser() {
		driver.quit();
	}
	

}
