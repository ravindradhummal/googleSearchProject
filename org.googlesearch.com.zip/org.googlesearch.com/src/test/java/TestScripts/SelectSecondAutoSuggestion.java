package TestScripts;

import org.testng.annotations.Test;
import Pages.GoogleSearchPage;

public class SelectSecondAutoSuggestion extends SuperTestNg {
	
	@Test
	public void selectText() throws InterruptedException {
		
		driver.get("https://www.google.com/");
		GoogleSearchPage gPage= new GoogleSearchPage(driver);
		gPage.selectSecondAutoSugegstionText(driver);	
	}

}
