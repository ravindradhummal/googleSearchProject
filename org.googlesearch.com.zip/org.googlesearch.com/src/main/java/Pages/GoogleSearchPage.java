package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class GoogleSearchPage {
	
	@FindBy(xpath="//input[@name=\"q\"]")
	private WebElement searchbar;
	
	@FindBy(xpath="(//div[@class=\"aajZCb\"]/..//span)[2]")
	private WebElement secondAutosuggestion;
	
	public GoogleSearchPage(WebDriver driver)
	{
		PageFactory.initElements(driver, this);
	}
	
	public void selectSecondAutoSugegstionText(WebDriver driver) throws InterruptedException
	{
		driver.manage().timeouts().setScriptTimeout(100, TimeUnit.SECONDS);
		searchbar.sendKeys("sql");
		WebDriverWait wait = new WebDriverWait(driver, 20);
		wait.until(ExpectedConditions.visibilityOf(secondAutosuggestion));
		secondAutosuggestion.click();
		Thread.sleep(2000);
	}

}
